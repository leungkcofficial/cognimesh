import os, re, shutil
from logger import setup_logger

# Create a logger for this module
logger = setup_logger(__name__)

def open_file(filepath):
    try:
        with open(filepath, 'r', encoding='utf-8') as infile:
            content = infile.read()
        logger.info(f"Opened file: {filepath}")
        return content
    except Exception as e:
        logger.error(f"Failed to open file: {filepath}. Error: {str(e)}")
        raise

def save_file(filepath, content):
    try:
        with open(filepath, 'w', encoding='utf-8') as outfile:
            outfile.write(content)
        logger.info(f"Saved file: {filepath}")
    except Exception as e:
        logger.error(f"Failed to save file: {filepath}. Error: {str(e)}")
        raise
        
def sanitize_filename(filename):
    logger.info(f"Sanitizing filename: {filename}")
    sanitized = re.sub(r'\W+', '_', filename)
    logger.info(f"Sanitized filename: {sanitized}")
    return sanitized

def delete_file(filepath):
    if os.path.isfile(filepath):
        os.remove(filepath)
        logger.info(f"Deleted file: {filepath}")
    else:
        logger.error(f"Error: {filepath} not a valid filename")
        
def move_file(source_filepath, destination_filepath):
    try:
        shutil.move(source_filepath, destination_filepath)
        logger.info(f"Moved file from {source_filepath} to {destination_filepath}")
    except Exception as e:
        logger.error(f"Failed to move file from {source_filepath} to {destination_filepath}. Error: {str(e)}")
        raise
    
def copy_file(source_filepath, destination_filepath):
    try:
        shutil.copy(source_filepath, destination_filepath)
        logger.info(f"Copied file from {source_filepath} to {destination_filepath}")
    except Exception as e:
        logger.error(f"Failed to copy file from {source_filepath} to {destination_filepath}. Error: {str(e)}")
        raise
    
def rename_file(old_path, new_path):
    try:
        os.rename(old_path, new_path)
        logger.info(f"Renamed file {old_path} to {new_path}")
    except Exception as e:
        logger.error(f"Error renaming file from {old_path} to {new_path}. Error: {str(e)}")
        raise