import os
from dotenv import load_dotenv, find_dotenv
import openai

# Read local .env file
load_dotenv(find_dotenv())

# Set OpenAI API Key
openai.api_key = os.getenv('OPENAI_API_KEY')

def llm_core(prompt_input, user_input, model="gpt-3.5-turbo", temperature=0.7, frequency_penalty=0, presence_penalty=0, max_tokens=None):
    messagein = [
        {"role": "system", "content": prompt_input},
        {"role": "user", "content": user_input}]
    response = openai.ChatCompletion.create(
        model=model,
        temperature=temperature,
        frequency_penalty=frequency_penalty,
        presence_penalty=presence_penalty,
        messages=messagein,
        max_tokens=max_tokens
    )
    text = response['choices'][0]['message']['content']
    return text