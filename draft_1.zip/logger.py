import logging
import os
from datetime import date
from dotenv import load_dotenv, find_dotenv

# Load environment variables
load_dotenv(find_dotenv())

# Check if the LOG_DIR environment variable is set
LOG_DIR = os.getenv('LOG_DIR')

if not LOG_DIR:
    # If not, default to a logs directory in the same location as this script
    LOG_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'logs')

# Create the log directory if it doesn't exist
os.makedirs(LOG_DIR, exist_ok=True)

def setup_logger(script_name):
    # Create a logger with the script name
    logger = logging.getLogger(script_name)

    # Set the log level to record all messages
    logger.setLevel(logging.DEBUG)

    # Create a file handler that logs debug and higher level messages to a file
    log_file = os.path.join(LOG_DIR, f"{script_name}_{date.today().isoformat()}.log")
    file_handler = logging.FileHandler(log_file)
    file_handler.setLevel(logging.DEBUG)

    # Create a console handler that logs error and higher level messages to the console
    console_handler = logging.StreamHandler()
    console_handler.setLevel(logging.ERROR)

    # Create a formatter and add it to the handlers
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')
    file_handler.setFormatter(formatter)
    console_handler.setFormatter(formatter)

    # Add the handlers to the logger
    logger.addHandler(file_handler)
    logger.addHandler(console_handler)

    return logger
