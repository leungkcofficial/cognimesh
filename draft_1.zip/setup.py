import os

# Default values for each environment variable
DEFAULT_VALUES = {
    'OPENAI_API_KEY': 'default_openai_api_key',
    'ZOTERO_LIBRARY_ID': 'default_zotero_library_id',
    'ZOTERO_API_KEY': 'default_zotero_api_key',
    'ZOTFILE_FOLDER': 'default_zotfile_folder',
    'LOG_DIR': 'logs',
    'INPUT_DIR': 'input',
    'OUTPUT_DIR': 'output',
}

# Try to read the .env file
try:
    with open('.env', 'r') as f:
        lines = f.readlines()
except FileNotFoundError:
    print("Error: .env file not found.")
    exit(1)

# Iterate over each line in the .env file
for i, line in enumerate(lines):
    # If the line contains an equals sign, it's an environment variable
    if '=' in line:
        # Split the line into the variable name and value
        var_name, var_value = line.strip().split('=')
        
        # If the variable value is blank, ask the user to input a value
        if var_value == '':
            while True:
                new_value = input(f"Enter a value for {var_name} (leave blank for default): ")
                
                # If the user didn't enter a value, use the default value
                if new_value == '':
                    new_value = DEFAULT_VALUES[var_name]
                
                # Validate the new value
                if new_value:  # Add any validation rules here
                    break
                else:
                    print("Invalid value. Please try again.")
            
            # Update the line with the new value
            lines[i] = f"{var_name}={new_value}\n"

# Write the updated lines back to the .env file
with open('.env', 'w') as f:
    f.writelines(lines)

# Check if the LOG_DIR, INPUT_DIR, and OUTPUT_DIR directories exist, and if they don't, create them
for var_name in ['LOG_DIR', 'INPUT_DIR', 'OUTPUT_DIR']:
    dir_path = os.getenv(var_name)
    if dir_path and not os.path.exists(dir_path):
        os.makedirs(dir_path)
        print(f"Created directory: {dir_path}")